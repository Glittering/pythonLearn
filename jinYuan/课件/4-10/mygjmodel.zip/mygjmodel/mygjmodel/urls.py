from django.conf.urls import patterns, include, url
from django.contrib import admin
from gjmodel.views import *
from gjmodel.models import *

teacher = Teacher.objects.get(id = 2)
data = Student.gender_count.all()
urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'mygjmodel.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^school/$',school,{'teacher':teacher}),
    url(r'^student/$',student,{'teacher':teacher}),
    #url(r'^hello/$',hello),
    url(r'^hello/$',hello,{
        'data':data,
        'template_name':'hello.html'
    }),
    url(r'^fenye/(\d+)/$',fenye),
    url(r'^fy/$',Fy.as_view())
)
