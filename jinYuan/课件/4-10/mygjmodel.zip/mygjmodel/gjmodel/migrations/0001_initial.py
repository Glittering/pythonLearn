# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Banji',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=30, verbose_name=b'\xe7\x8f\xad\xe7\xba\xa7\xe5\x90\x8d\xe7\xa7\xb0')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Teacher',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=30, verbose_name=b'\xe6\x95\x99\xe5\xb8\x88\xe5\xa7\x93\xe5\x90\x8d')),
                ('age', models.IntegerField(verbose_name=b'\xe6\x95\x99\xe5\xb8\x88\xe5\xb9\xb4\xe9\xbe\x84')),
                ('gender', models.CharField(max_length=10, verbose_name=b'\xe6\x95\x99\xe5\xb8\x88\xe6\x80\xa7\xe5\x88\xab')),
                ('subject', models.CharField(max_length=20, verbose_name=b'\xe6\x95\x99\xe6\x8e\x88\xe7\xa7\x91\xe7\x9b\xae')),
                ('tel', models.CharField(max_length=11, verbose_name=b'\xe8\x81\x94\xe7\xb3\xbb\xe6\x96\xb9\xe5\xbc\x8f')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='banji',
            name='teacher',
            field=models.ForeignKey(verbose_name=b'\xe4\xbb\xbb\xe8\xaf\xbe\xe6\x95\x99\xe5\xb8\x88', to='gjmodel.Teacher'),
            preserve_default=True,
        ),
    ]
