# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('gjmodel', '0002_student'),
    ]

    operations = [
        migrations.AddField(
            model_name='student',
            name='teacher',
            field=models.ManyToManyField(to='gjmodel.Teacher', verbose_name=b'\xe4\xb8\x93\xe4\xb8\x9a\xe8\x80\x81\xe5\xb8\x88'),
            preserve_default=True,
        ),
    ]
