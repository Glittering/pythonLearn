#coding:utf-8
from django.shortcuts import render_to_response
from models import *

def school(request,teacher):
    #teacher = Teacher.objects.get(id = 2)
    teach_cl = teacher.banji_set.all()
    cl = Banji.objects.get(id = 1)
    cl_teacher = cl.teacher
    return render_to_response('school.html',locals())

def student(request,teacher):
    #teacher = Teacher.objects.get(id = 2)
    teach_stud = teacher.student_set.all()
    stud = Student.objects.get(id = 2)
    stud_teach = stud.teacher.all
    return render_to_response('student.html',locals())
'''
def hello(request):
    count = Student.objects.age_count(20)
    #a = Student.objects.filter(age = 20).count()
    data = Student.gender_count.all()
    return render_to_response('hello.html',locals())
'''

def hello(request,data,template_name):
    return render_to_response(template_name,locals())


def fenye(request,num):
    num = int(num)
    data = Student.objects.all()[(num-1) * 3:num * 3]
    return render_to_response('fenye.html',locals())

from django.views.generic import ListView

class Fy(ListView):
    model = Student    #模型的名称
    paginate_by = 3    #每页显示的条目个数
    context_object_name = 'student'  #模板当中变量的名字
    template_name = 'fy.html'  #模板的名字

# Create your views here.
