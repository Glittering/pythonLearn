from django.contrib import admin
from models import *


class TeacherAdmin(admin.ModelAdmin):
    list_display = ['id','name','age','subject']

class BanjiAdmin(admin.ModelAdmin):
    list_display = ['id','name']

class StudentAdmin(admin.ModelAdmin):
    list_display = ['id','name','age','major']

admin.site.register(Teacher,TeacherAdmin)
admin.site.register(Banji,BanjiAdmin)
admin.site.register(Student,StudentAdmin)
# Register your models here.
