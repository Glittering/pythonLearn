#coding:utf-8
from django.db import models

class Teacher(models.Model):
    name = models.CharField(max_length = 30,verbose_name = '教师姓名')
    age = models.IntegerField(verbose_name = '教师年龄')
    gender = models.CharField(max_length = 10,verbose_name = '教师性别')
    subject = models.CharField(max_length = 20,verbose_name = '教授科目')
    tel = models.CharField(max_length = 11,verbose_name = '联系方式')

    def __unicode__(self):
        return self.name

class Banji(models.Model):
    name = models.CharField(max_length = 30,verbose_name = '班级名称')
    teacher = models.ForeignKey(Teacher,verbose_name = '任课教师')

    def __unicode__(self):
        return self.name

class StudentManager(models.Manager):
    def age_count(self,keyword):
        return self.filter(age = keyword).count()

class  StudManager(models.Manager):
    def get_queryset(self):
        return super(StudManager,self).get_queryset().filter(gender = '女')

class Student(models.Model):
    name = models.CharField(max_length = 30,verbose_name = '学生姓名')
    age = models.IntegerField(verbose_name = '学生年龄')
    gender = models.CharField(max_length = 10,verbose_name = '学生性别')
    major = models.CharField(max_length = 20,verbose_name = '专业')
    tel = models.CharField(max_length = 11,verbose_name = '联系方式')
    teacher = models.ManyToManyField(Teacher,verbose_name = '专业老师')
    nation = models.CharField(max_length = 30,verbose_name = '民族')
    objects = StudentManager()
    gender_count = StudManager()

    def __unicode__(self):
        return self.name

    def check_age(self):
        if 20 < self.age < 35:
            return 'very nice!!!'
        elif self.age <= 20:
            return 'your may be too young'
        elif self.age >= 35:
            return '你太老了'
# Create your models here.
