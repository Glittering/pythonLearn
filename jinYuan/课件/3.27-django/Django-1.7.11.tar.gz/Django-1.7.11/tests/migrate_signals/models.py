# This module has to exist, otherwise pre/post_migrate aren't sent for the
# migrate_signals application.
