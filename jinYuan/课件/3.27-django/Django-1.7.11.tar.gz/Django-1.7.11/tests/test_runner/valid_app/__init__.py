# Example of app layout to verify that the fix for #12658 doesn't break test
# discovery when both `models` and `tests` are packages.
# `test_runner` tests perform test discovery on this app.
