import unittest


class SampleTest(unittest.TestCase):

    def test_one(self):
        pass
