from django.conf.urls import patterns, include, url
from django.contrib import admin
from ajax.views import *

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'myajax.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^ajax_get/$',ajax_get),
    url(r'^ajax_GET/$',ajax_GET),
    url(r'^ajax_get_color/$',ajax_get_color),
    url(r'^ajax_GET_color/$',ajax_GET_color),
    url(r'^ajax_get_changecolor/$',ajax_get_changecolor),
    url(r'^ajax_GET_changecolor/$',ajax_GET_changecolor),
    url(r'^ajax_post/$',ajax_post),
    url(r'^ajax_POST$',ajax_POST)
)
