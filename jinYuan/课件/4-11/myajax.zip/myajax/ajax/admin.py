from django.contrib import admin
from models import *

class ColorAdmin(admin.ModelAdmin):
    list_display = ['id','color','datetime']

admin.site.register(Color,ColorAdmin)
# Register your models here.
