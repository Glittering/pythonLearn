from django.shortcuts import render_to_response
from django.http import JsonResponse

def ajax_get(request):
    return render_to_response('ajax_get.html',locals())

def ajax_GET(request):
    return JsonResponse({'name':'xiaoqiang'})

def ajax_get_color(request):
    return render_to_response('ajax_get_color.html')

def ajax_GET_color(request):
    return JsonResponse({'color':'skyblue'})

def ajax_get_changecolor(request):
    return render_to_response('ajax_get_changecolor.html',locals())

def ajax_GET_changecolor(request):
    if request.method == 'GET':
        if 'color' in request.GET and request.GET['color']:
            color = request.GET['color']
    return JsonResponse({'color':color})

from models import *
def ajax_post(request):
    return render_to_response('ajax_post.html',locals())

def ajax_POST(request):
    if request.method == 'POST':
        if 'color' in request.POST and request.POST['color']:
            color = request.POST['color']
            Color.objects.create(color = color)
    return JsonResponse({'color':color})
# Create your views here.
