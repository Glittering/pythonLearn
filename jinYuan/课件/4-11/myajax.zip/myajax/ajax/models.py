from django.db import models

class Color(models.Model):
    color = models.CharField(max_length = 30)
    datetime = models.DateTimeField(auto_now_add = True)

    def __unicode__(self):
        return self.color
# Create your models here.
